---
name: reference-study
description: Break down inspiration reels into a structured, reusable style note (hook, cut rhythm, caption style, audio, CTA) from frames, timings and transcript. Use whenever the user shares a reference reel, asks to copy a style, or wants to learn why a competitor video works.
---

# Reference study

The agent cannot "watch" video; it reads frames, numbers and text. For each reference file:
1. Contact sheet: `ffmpeg -i ref.mp4 -vf "fps=2,scale=216:-1,tile=6x5" -frames:v 1 sheet.jpg`
2. Cut times: `ffmpeg -i ref.mp4 -vf "select='gt(scene,0.25)',showinfo" -an -f null - 2>&1 | grep -o 'pts_time:[0-9.]*'`
3. Loudness and silence: `ffmpeg -i ref.mp4 -af ebur128=peak=true -f null -` and `silencedetect`.
4. Transcript with word timings (Whisper-style) if there is speech.
5. Write `references/<account>-<id>.md`:
   - Hook (first 3 s): text, visual, pattern name
   - Beat timings table (t_start, t_end, shot, camera, on-screen text, audio event)
   - Cuts per second, longest hold, caption style/position, loudness, music level
   - CTA wording and where it appears
   - One line: why it works / what to copy (structure only)
Copy structure and pacing, never footage, voice or exact wording. Keep notes short so they can be loaded as context for new scripts.
