---
name: audio-mix
description: Audio mixing and loudness rules for reels - voice level, music ducking, -14 LUFS / -1 dBTP target, silence trimming, two-pass loudness normalization script. Use whenever mixing voice, music or SFX, fixing quiet or clipping audio, or doing the final audio pass on any video.
---

# Audio mix

## Targets
- Integrated loudness about -14 LUFS, true peak -1 dBTP or lower. Instagram does not publish its own target (about -14 is the common estimate); TikTok and YouTube Shorts are commonly cited at -14 too. Quiet files (e.g. -23 LUFS) sound weak on phones.
- Voice peaks around -6 dBFS before the final pass; clean voice first, loudness last.
- Music bed 10-14 dB below the voice (sources range 6-14 dB; start at 12 dB, adjust by ear). SFX short, sparse, never on every cut.
- Trim leading silence to 0 and trailing silence to 0.3 s or less. Keep natural breaths.
- Apply final loudness and limiting once, at export, never stacked.

## Final pass
Run the bundled two-pass script on the rendered file:
```
python .agents/skills/audio-mix/scripts/loudnorm2pass.py episodes/<n>/out/final_raw.mp4 episodes/<n>/out/final.mp4
```
It measures, applies linear loudnorm to -14 LUFS / -1 dBTP, copies the video stream untouched, and re-encodes audio as AAC 192k @ 48 kHz. Then run `render-qc`.

If FilmCraft can do the loudness pass itself (see `filmcraft-edit`), use whichever one hits the target in QC.
