#!/usr/bin/env python3
"""Two-pass loudness normalization. Usage: loudnorm2pass.py in.mp4 out.mp4 [--lufs -14] [--tp -1.0] [--lra 11]
Needs ffmpeg on PATH. Video stream is copied untouched."""
import argparse, json, re, subprocess, sys

ap = argparse.ArgumentParser()
ap.add_argument("inp"); ap.add_argument("out")
ap.add_argument("--lufs", type=float, default=-14.0)
ap.add_argument("--tp", type=float, default=-1.0)  # limiter ceiling is set 0.5 dB below this for AAC overshoot
ap.add_argument("--lra", type=float, default=11.0)
a = ap.parse_args()

f1 = f"loudnorm=I={a.lufs}:TP={a.tp}:LRA={a.lra}:print_format=json"
r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", a.inp, "-af", f1, "-f", "null", "-"],
                   capture_output=True, text=True, encoding="utf-8", errors="replace")
m = re.findall(r"\{[^{}]*\}", r.stderr)
if not m:
    sys.exit("pass 1 failed: no loudnorm JSON\n" + r.stderr[-800:])
s = json.loads(m[-1])
f2 = (f"loudnorm=I={a.lufs}:TP={a.tp}:LRA={a.lra}:measured_I={s['input_i']}:measured_TP={s['input_tp']}"
      f":measured_LRA={s['input_lra']}:measured_thresh={s['input_thresh']}:offset={s['target_offset']}:linear=true"
      f",alimiter=limit={10 ** ((a.tp - 0.5) / 20):.4f}:attack=5:release=50:level=disabled")
r2 = subprocess.run(["ffmpeg", "-hide_banner", "-y", "-i", a.inp, "-c:v", "copy", "-af", f2,
                     "-c:a", "aac", "-b:a", "192k", "-ar", "48000", a.out], capture_output=True, text=True, encoding="utf-8", errors="replace")
if r2.returncode != 0:
    sys.exit("pass 2 failed\n" + r2.stderr[-800:])
print(json.dumps({"input_lufs": s["input_i"], "input_true_peak": s["input_tp"], "output": a.out}))
