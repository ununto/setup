---
name: render-qc
description: Automated and visual quality check for every finished reel - resolution, fps, duration, codec, loudness, true peak, silent tail, black first frame, cut rhythm, contact sheet and safe-zone overlay frames. Run after EVERY render and before telling the user a video is done, even for quick edits.
---

# Render QC

## Run
```
python .agents/skills/render-qc/scripts/qc.py episodes/<n>/out/final.mp4 --out episodes/<n>/out/qc
```
Prints a JSON report (also saved as `qc/report.json`) and exits 1 if any check FAILs.

## What it checks
FAIL: not 1080x1920, not H.264/yuv420p, no audio track, black first frame, loudness more than 3 LU from -14.
WARN: fps not ~30, duration outside 12-14.5 s, loudness 1.5-3 LU off, true peak above -1 dBTP, silent tail over 0.3 s, a shot holding over 4 s.
INFO: cut times, cuts per second, silence gaps.

## Then LOOK (the script cannot judge these)
Open `qc/contact_sheet.jpg` and the `qc/safe_*.png` frames (red bands = Reels UI zones):
1. Is hook text AND proof visible at 0.0-0.3 s?
2. Is every piece of text outside the red bands?
3. Is the URL readable on a phone-sized frame?
4. Does each caption/cut match what is being said at that moment?
5. Is browser footage sharp and full-bleed, not warped or re-filmed?
Fix anything that fails, re-render, re-run QC. Report the final numbers to the user.
