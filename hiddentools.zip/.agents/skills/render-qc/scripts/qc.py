#!/usr/bin/env python3
"""Reel QC. Usage: qc.py video.mp4 [--out DIR]. Needs ffmpeg + ffprobe + python3 (stdlib only)."""
import argparse, json, os, re, subprocess, sys

def run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")

ap = argparse.ArgumentParser()
ap.add_argument("video"); ap.add_argument("--out", default="qc")
a = ap.parse_args()
os.makedirs(a.out, exist_ok=True)

res = {"file": a.video, "checks": []}
def chk(name, status, detail):
    res["checks"].append({"check": name, "status": status, "detail": detail})

p = json.loads(run(["ffprobe", "-v", "error", "-show_entries",
    "format=duration:stream=codec_type,codec_name,width,height,r_frame_rate,pix_fmt", "-of", "json", a.video]).stdout)
v = next((s for s in p["streams"] if s["codec_type"] == "video"), None)
au = next((s for s in p["streams"] if s["codec_type"] == "audio"), None)
dur = float(p["format"]["duration"])
res["duration_s"] = round(dur, 3)

if not v:
    chk("video_stream", "FAIL", "no video stream")
else:
    chk("resolution", "PASS" if (v["width"], v["height"]) == (1080, 1920) else "FAIL", f'{v["width"]}x{v["height"]}')
    n, d = v["r_frame_rate"].split("/"); fps = float(n) / float(d)
    chk("fps", "PASS" if 29.9 <= fps <= 30.1 else "WARN", f"{fps:.2f}")
    ok = v["codec_name"] == "h264" and v.get("pix_fmt") == "yuv420p"
    chk("codec", "PASS" if ok else "FAIL", f'{v["codec_name"]}/{v.get("pix_fmt")}')
chk("duration", "PASS" if 12 <= dur <= 14.5 else "WARN", f"{dur:.2f}s (target 12-14.5)")

if not au:
    chk("audio_stream", "FAIL", "no audio track")
else:
    e = run(["ffmpeg", "-nostats", "-i", a.video, "-af", "ebur128=peak=true", "-f", "null", "-"]).stderr
    summ = e[e.rfind("Summary:"):] if "Summary:" in e else e
    I = re.findall(r"I:\s+(-?[\d.]+) LUFS", summ)
    TP = re.findall(r"Peak:\s+(-?[\d.]+) dBFS", summ)
    if I:
        i = float(I[-1]); off = abs(i + 14)
        chk("loudness", "PASS" if off <= 1.5 else ("WARN" if off <= 3 else "FAIL"), f"{i} LUFS (target -14)")
    if TP:
        tp = float(TP[-1]); chk("true_peak", "PASS" if tp <= -1.0 else "WARN", f"{tp} dBTP (max -1.0)")
    s = run(["ffmpeg", "-nostats", "-i", a.video, "-af", "silencedetect=n=-40dB:d=0.25", "-f", "null", "-"]).stderr
    st = [float(x) for x in re.findall(r"silence_start: (-?[\d.]+)", s)]
    en = [float(x) for x in re.findall(r"silence_end: (-?[\d.]+)", s)]
    gaps = [(round(x, 2), round(y, 2)) for x, y in zip(st, en)]
    if len(st) > len(en): gaps.append((round(st[-1], 2), round(dur, 2)))
    tail = max([dur - g[0] for g in gaps if g[1] >= dur - 0.06] or [0.0])
    chk("silent_tail", "PASS" if tail <= 0.3 else "WARN", f"{tail:.2f}s (max 0.3)")
    res["silence_gaps"] = gaps

b = run(["ffmpeg", "-nostats", "-i", a.video, "-vf", "blackdetect=d=0.05:pic_th=0.95", "-an", "-f", "null", "-"]).stderr
bs = [float(x) for x in re.findall(r"black_start:([\d.]+)", b)]
chk("black_first_frame", "FAIL" if any(x < 0.3 for x in bs) else "PASS", f"black segments start at {bs}" if bs else "none")

sc = run(["ffmpeg", "-i", a.video, "-vf", "select='gt(scene,0.25)',showinfo", "-an", "-f", "null", "-"]).stderr
cuts = [float(x) for x in re.findall(r"pts_time:([\d.]+)", sc)]
edges = [0.0] + cuts + [dur]
longest = max(y - x for x, y in zip(edges, edges[1:]))
chk("longest_hold", "PASS" if longest <= 4 else "WARN", f"{longest:.1f}s between detected cuts (info: demos may hold if the screen changes)")
res["cuts_s"] = cuts; res["cuts_per_s"] = round(len(cuts) / dur, 2)

zones = ("drawbox=y=0:w=iw:h=ih*0.14:color=red@0.3:t=fill,drawbox=y=ih*0.65:w=iw:h=ih*0.35:color=red@0.3:t=fill,"
         "drawbox=x=0:y=0:w=iw*0.06:h=ih:color=red@0.3:t=fill,drawbox=x=iw*0.94:y=0:w=iw*0.06:h=ih:color=red@0.3:t=fill")
for t in [0.3, 3.0, dur / 2, max(dur - 0.5, 0)]:
    run(["ffmpeg", "-v", "error", "-y", "-ss", f"{t:.2f}", "-i", a.video, "-frames:v", "1",
         "-vf", "scale=540:-1," + zones, os.path.join(a.out, f"safe_{t:.1f}s.png")])
run(["ffmpeg", "-v", "error", "-y", "-i", a.video, "-vf", "fps=2,scale=216:-1,tile=6x5", "-frames:v", "1",
     os.path.join(a.out, "contact_sheet.jpg")])

res["verdict"] = "FAIL" if any(c["status"] == "FAIL" for c in res["checks"]) else (
    "WARN" if any(c["status"] == "WARN" for c in res["checks"]) else "PASS")
json.dump(res, open(os.path.join(a.out, "report.json"), "w"), indent=2)
print(json.dumps(res, indent=2))
sys.exit(1 if res["verdict"] == "FAIL" else 0)
