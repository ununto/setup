#!/usr/bin/env python
"""Turn a landscape screen recording into a 1080x1920 clip made of zoomed beats (no blur bars).
Usage: reframe.py plan.json --out episodes/001/prep/demo_framed.mp4 [--preview DIR] [--preview-only]
plan.json:
{
  "source": "episodes/001/raw/demo.mp4",
  "content": {"left": 0.0, "top": 0.10, "right": 0.0, "bottom": 0.06},
  "beats": [
    {"t_start": 0.0, "t_end": 2.5, "cx": 0.5, "cy": 0.3, "h": 0.55, "push": 1.10},
    {"t_start": 2.5, "t_end": 7.0, "cx": 0.55, "cy": 0.6, "h": 0.45}
  ]
}
Beat modes:
  window (default): 9:16 crop around cx,cy,h (good for TALL things).
  panel: keeps a WIDE element fully visible and sharp: crop box {x,y,w,h} (fractions of content),
         scale to fit 1080 wide x 978 tall (the safe box), place centered at center_y (default 759)
         on a solid background "bg" (match the site, default #0a0a0f). Leaves room for headline/caption text.
         Example: {"t_start":6.6,"t_end":11.2,"mode":"panel","box":{"x":0.35,"y":0.41,"w":0.27,"h":0.59},"bg":"#0a0a0f"}
content: fractions trimmed from each source edge (browser tabs/URL bar, taskbar, "sharing" bar).
cx, cy: window center as fractions of the CONTENT area. h: window height as a fraction of content
height (smaller = more zoom); width follows 9:16. push: optional eased punch-in multiplier (1.0-1.25).
Needs ffmpeg + ffprobe on PATH. Python stdlib only."""
import argparse, json, os, subprocess, sys, tempfile

def run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")

ap = argparse.ArgumentParser()
ap.add_argument("plan"); ap.add_argument("--out", required=True)
ap.add_argument("--preview"); ap.add_argument("--preview-only", action="store_true")
a = ap.parse_args()
plan = json.load(open(a.plan, encoding="utf-8"))
src = plan["source"]
pr = json.loads(run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                     "stream=width,height", "-of", "json", src]).stdout)["streams"][0]
W, H = pr["width"], pr["height"]
c = plan.get("content", {})
x0, y0 = int(c.get("left", 0) * W), int(c.get("top", 0) * H)
cw = W - x0 - int(c.get("right", 0) * W); ch = H - y0 - int(c.get("bottom", 0) * H)
ev = lambda v: int(v) // 2 * 2
clamp = lambda v, lo, hi: max(lo, min(hi, v))

beats, report = [], []
for k, b in enumerate(plan["beats"]):
    if b.get("mode") == "panel":
        bb = b["box"]
        bw = ev(clamp(bb["w"], 0.02, 1.0) * cw); bh = ev(clamp(bb["h"], 0.02, 1.0) * ch)
        bx = ev(x0 + clamp(bb["x"] * cw, 0, cw - bw)); by = ev(y0 + clamp(bb["y"] * ch, 0, ch - bh))
        sc = min(1080 / bw, b.get("max_h", 978) / bh)
        tw, th = ev(bw * sc), ev(bh * sc)
        yt = ev(clamp(b.get("center_y", 759) - th / 2, 270, max(270, 1248 - th)))
        b["_panel"] = (tw, th, yt, str(b.get("bg", "#0a0a0f")).replace("#", "0x"))
        warns = []
        if sc > 1.8: warns.append(f"scale {sc:.1f}x: fine for glow/particles/photos, soft for small text")
        if b["t_end"] <= b["t_start"]: warns.append("t_end must be > t_start")
        beats.append((b, bw, bh, bx, by))
        report.append({"beat": k, "mode": "panel", "t": [b["t_start"], b["t_end"]], "box_px": [bx, by, bw, bh],
                       "scale_x": round(sc, 2), "placed_px": [(1080 - tw) // 2, yt, tw, th], "warnings": warns})
        continue
    rh = clamp(b.get("h", 1.0), 0.05, 1.0) * ch; rw = rh * 9 / 16
    if rw > cw: rw = cw; rh = rw * 16 / 9
    rw, rh = ev(rw), ev(rh)
    x = ev(x0 + clamp(b.get("cx", 0.5) * cw - rw / 2, 0, cw - rw))
    y = ev(y0 + clamp(b.get("cy", 0.5) * ch - rh / 2, 0, ch - rh))
    up = 1920 / rh * b.get("push", 1.0)
    warns = []
    if up > 2.2: warns.append(f"upscale {up:.1f}x: will look soft; record bigger (browser zoom) instead of zooming in the edit")
    if b["t_end"] <= b["t_start"]: warns.append("t_end must be > t_start")
    beats.append((b, rw, rh, x, y))
    report.append({"beat": k, "t": [b["t_start"], b["t_end"]], "window_px": [x, y, rw, rh],
                   "upscale_x": round(up, 2), "warnings": warns})

if a.preview:
    os.makedirs(a.preview, exist_ok=True)
    for k, (b, rw, rh, x, y) in enumerate(beats):
        t = b["t_start"] + min(0.5, (b["t_end"] - b["t_start"]) / 2)
        vf = (f"drawbox=x={x0}:y={y0}:w={cw}:h={ch}:color=yellow@0.9:t=4,"
              f"drawbox=x={x}:y={y}:w={rw}:h={rh}:color=red@0.95:t=8,scale=640:-1")
        run(["ffmpeg", "-v", "error", "-y", "-ss", f"{t:.2f}", "-i", src, "-frames:v", "1", "-vf", vf,
             os.path.join(a.preview, f"beat_{k}.png")])
if a.preview_only:
    print(json.dumps(report, indent=2)); sys.exit(0)

tmp = tempfile.mkdtemp(prefix="reframe_"); parts = []
for k, (b, rw, rh, x, y) in enumerate(beats):
    d = b["t_end"] - b["t_start"]; P = b.get("push", 1.0)
    if b.get("mode") == "panel":
        tw, th, yt, bg = b["_panel"]
        vf = (f"crop={rw}:{rh}:{x}:{y},scale={tw}:{th}:flags=lanczos,"
              f"pad=1080:1920:{(1080 - tw) // 2}:{yt}:color={bg}")
        P = 1.0
    else:
        vf = f"crop={rw}:{rh}:{x}:{y},scale=1080:1920:flags=lanczos"
    if P > 1.0:
        s = f"(pow(min(t/{d:.3f},1),2)*(3-2*min(t/{d:.3f},1)))"
        vf += (f",scale=w='trunc(1080*(1+{P - 1:.3f}*{s})/2)*2':h='trunc(1920*(1+{P - 1:.3f}*{s})/2)*2'"
               f":eval=frame:flags=bicubic,crop=1080:1920")
    vf += ",fps=30,format=yuv420p"
    part = os.path.join(tmp, f"p{k}.mp4"); parts.append(part)
    r = run(["ffmpeg", "-hide_banner", "-y", "-ss", f"{b['t_start']:.3f}", "-t", f"{d:.3f}", "-i", src,
             "-vf", vf, "-an", "-c:v", "libx264", "-crf", "16", "-preset", "medium",
             "-r", "30", "-fps_mode", "cfr", part])
    if r.returncode != 0:
        sys.exit(f"beat {k} failed:\n{r.stderr[-600:]}")
lst = os.path.join(tmp, "list.txt")
open(lst, "w", encoding="utf-8").write("".join(f"file '{p.replace(chr(92), '/')}'\n" for p in parts))
os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
r = run(["ffmpeg", "-hide_banner", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", a.out])
if r.returncode != 0: sys.exit("concat failed:\n" + r.stderr[-600:])
o = json.loads(run(["ffprobe", "-v", "error", "-show_entries", "format=duration:stream=width,height,r_frame_rate",
                    "-of", "json", a.out]).stdout)
print(json.dumps({"output": a.out, "format": o["format"], "stream": o["streams"][0], "beats": report}, indent=2))
