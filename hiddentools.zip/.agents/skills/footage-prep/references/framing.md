# Framing desktop screen recordings for 9:16

## Decision: record for quality, frame in the edit
- RECORDING decides sharpness. Browser zoom re-renders text crisply; editing zoom only enlarges pixels.
- EDITING decides framing. Pick a crop window per beat after you know the script and voice timing, so you can change it without re-recording.

## Why pixels matter
A 9:16 window cut from a 1920x1080 source is at most 608x1080 px, already a 1.78x upscale to 1080x1920. Every extra zoom in the edit makes it softer (reframe.py warns above 2.2x). Fix it at the source: browser zoom 150-200%, window-only capture, 1440p if the PC allows (avoid 4K HEVC: slow renders).

## Recording checklist (before pressing record)
1. Capture the browser WINDOW only, not the whole desktop. Hide taskbar (auto-hide), bookmarks bar, extensions; no "sharing your screen" bar (use OBS/Game Bar window capture); press F11 for full-screen.
2. Browser zoom 150-200% (Ctrl +). Check that key UI text is readable when the frame is shrunk to phone width.
3. Resolution 1920x1080 minimum, 30 fps, H.264. No HDR.
4. Keep the action in ONE area (the preview panel); move the cursor slowly; hold the result for 1 s.
5. Record 2 s extra at the start and end.
6. Optional: if the site's mobile layout looks good, record it in DevTools device mode (about 430x932) and skip cropping entirely. Check the layout still shows the feature you demo.

## The geometry rule (check BEFORE choosing a window)
A 9:16 window can only contain an element if  element_width <= 0.5625 x window_height  (window_height is at most the content height, about 840 px on a 1080p recording => elements up to ~470 px wide).
- Element narrower than that (tall panels, a small ring, a sidebar list): `window` mode.
- Element wider (headline text, carousels, code cards, anything 500+ px wide): `panel` mode. It crops the element, scales it to fit 1080 wide x 978 tall (the safe box), and places it on a solid background colour sampled from the site (so it looks full-bleed, no blur). Headline and caption go above/below it in the safe box.
- Never slice a wide element with a narrow window: you get a fragment (half a headline, one card of a carousel) upscaled 3-4x.
- Scale tolerance: glow, particles, photos can take ~2x; small UI text should stay under ~1.5x.

## Beat plan (3 beats for a 13 s reel; times come from the voice anchors)
| Beat | Shows | Window (content fractions) |
|---|---|---|
| 1 context | page headline / what the tool is | usually `panel` (headline block is wide) |
| 2 action | the component/effect actually working | `panel` around the effect with a margin, or `window` if tall |
| 3 proof | the finished result or the install/copy step | `panel` for wide results; `window` + push 1.10 only for tall ones |

## Steps
1. Look at 6-8 frames of the recording (ffmpeg contact sheet). Note what UI chrome to trim (tabs, URL bar, taskbar) as `content` fractions.
2. Write `plan.json` (see reframe.py docstring), run with `--preview-only --preview DIR`, LOOK at each beat_N.png: yellow = content area, red = 9:16 window. Adjust cx/cy/h until the red box contains exactly what matters.
3. Run without `--preview-only` -> `episodes/<n>/prep/demo_framed.mp4`.
4. Import that one clip into FilmCraft (scale 100, position 540,960). Beats are hard cuts; line them up with voice words.
5. Text goes in the safe box (y 270-1248). Choose windows so the key action sits around y 700-1200 and the upper third is dark or empty enough for the headline.

## Do not
- Use fit-blur for desktop demos (tiny UI, blurred copies add noise).
- Pick the panel background from a screenshot of the site (sample a plain background pixel), not from guesswork.
- Zoom beyond ~2.2x upscale; re-record with higher browser zoom instead.
- Leave browser chrome, taskbar or screen-share banners in frame.
