---
name: filmcraft-edit
description: How to drive the FilmCraft CLI to assemble reels - import clips, place and trim at exact times, speed, text, captions, audio, export. Use for ANY assembly, trimming, captioning or export step in this project.
---

# FilmCraft CLI

Exact working invocation:
```powershell
& "D:\7th SEM\FilmCraft\filmcraft-cli.exe"
```

## Overview & Invocation Patterns
FilmCraft CLI `0.12.0` operates headless or via WebSocket bridge (`--bridge 127.0.0.1:PORT`).
- **Single Command (`exec`)**:
  ```powershell
  & "D:\7th SEM\FilmCraft\filmcraft-cli.exe" exec <id> [key=value ...]
  & "D:\7th SEM\FilmCraft\filmcraft-cli.exe" exec <id> '<json params>'
  ```
- **Batch Pipeline (`run`)**:
  Executes commands sequentially from a JSONL script or stdin (`-`). Note that `file.exportMedia` waits for export completion by default unless `"wait": false`.
  ```powershell
  & "D:\7th SEM\FilmCraft\filmcraft-cli.exe" [--project <file.fcproj>] [--save-as <file.fcproj>] run <script.jsonl | ->
  ```
- **Direct CLI Export**:
  ```powershell
  & "D:\7th SEM\FilmCraft\filmcraft-cli.exe" --project <file.fcproj> export <out.mp4> --preset "Social Vertical 1080×1920"
  ```
- **Time Units**:
  FilmCraft uses 254,016,000,000 ticks per second (`254016000000`). Commands accept `seconds=f64`, `frame=i64`, or `time=ticks`.

## Decisions
- **Footage preparation**: Run `footage-prep` before importing (`python .agents/skills/footage-prep/scripts/normalize.py episodes/<n>/raw/* --out episodes/<n>/prep --mode fill`). Import ONLY normalized files from `prep/`. After prep, all footage is natively 1080x1920 CFR at 30 fps, so clips need scale `100` and position `[540, 960]`.
- **Captions**: Captions are NOT done in FilmCraft any more. FilmCraft caption tracks cannot highlight individual words. Export without captions (`burnCaptions: false`) to `out/final_raw.mp4`, then run the `word-captions` skill (pop-in ASS karaoke burned via ffmpeg with `fontsdir=assets/fonts`).
- **Pipeline Order**: FilmCraft export without captions -> `out/final_raw.mp4` -> `word-captions` (`out/final_captioned.mp4`) -> `audio-mix` (`loudnorm2pass.py` -> `out/final.mp4`) -> `render-qc`.
- **Loudness**: use `audio-mix/scripts/loudnorm2pass.py` only; do not also set `loudnessLufs`.
- **Working directory**: Run FilmCraft from the project root so relative `episodes/...` paths resolve.
- **Time units**: Prefer `seconds` over ticks in commands; `ticks = seconds * 254016000000`.

## Commands that work

### Import clips/audio
- CLI command:
  ```powershell
  & "D:\7th SEM\FilmCraft\filmcraft-cli.exe" import <file>...
  ```
- Exec / batch command:
  ```json
  {"id": "file.import", "params": {"paths": ["episodes/001/prep/clip1_1080x1920.mp4", "episodes/001/raw/vo.wav"], "bin": null, "replace": false}}
  ```
  Returns `{"items": [<item_id>, ...]}`.
- Built-in demo footage:
  ```json
  {"id": "file.importDemoFootage", "params": {"scene": "OceanSunset|Aurora|CityNight|Dunes|Plasma|Forest"}}
  ```

### Trim / place at exact milliseconds
- Place clips/audio on timeline tracks (`V1`, `V2`, `A1`, `A2`):
  ```json
  {"id": "timeline.place", "params": {"item": <item_id>, "track": "V1", "seconds": 0.0, "duration": <ticks>, "insert": false, "video": true, "audio": true}}
  ```
- Trim in/out edit points:
  ```json
  {"id": "timeline.trim", "params": {"clip": <clip_id>, "edge": "in|out", "mode": "regular|ripple", "delta": <ticks>}}
  ```
- Razor / split clip at timestamp:
  ```json
  {"id": "timeline.razor", "params": {"time": <ticks>, "track": "V1", "clip": <clip_id>}}
  ```
- Move clips across timeline / tracks:
  ```json
  {"id": "timeline.move", "params": {"moves": [{"clip": <clip_id>, "track": "V1"|"V2"|"new", "time": <ticks>}], "insert": false}}
  ```

### Reorder / transitions
- Video transitions:
  ```json
  {"id": "sequence.applyVideoTransition", "params": {"clip": <clip_id>, "effect": "cross_dissolve|dip_to_black|push|slide|zoom", "align": "start|center|end", "duration": <ticks>}}
  ```
- Audio transitions:
  ```json
  {"id": "sequence.applyAudioTransition", "params": {"clip": <clip_id>, "effect": "constant_power|constant_gain|exponential_fade", "align": "start|center|end", "duration": <ticks>}}
  ```
- Modify or remove transitions:
  ```json
  {"id": "sequence.setTransition", "params": {"transition": <id>, "duration": <ticks>, "align": "center"}}
  {"id": "sequence.removeTransition", "params": {"transitions": [<id>]}}
  ```

### Speed / retime
- Retime clip speed & direction:
  ```json
  {"id": "clip.speedDuration", "params": {"clips": [<clip_id>], "speed": 100.0, "reverse": false, "ripple": false, "interpolation": "frameSampling|frameBlending|opticalFlow"}}
  ```

### Zoom / crop / reframe
- Motion intrinsic properties (scale, position, anchor, rotation):
  ```json
  {"id": "effects.setParam", "params": {"clip": <clip_id>, "effect": "motion", "param": "scale", "value": 100.0}}
  {"id": "effects.setParam", "params": {"clip": <clip_id>, "effect": "motion", "param": "position", "value": [540.0, 960.0]}}
  {"id": "effects.setParam", "params": {"clip": <clip_id>, "effect": "motion", "param": "rotation", "value": 0.0}}
  ```
- Built-in video effects via `effects.apply`:
  `crop`, `rounded_crop`, `auto_reframe`, `transform`, `lumetri`, `gaussian_blur`, `drop_shadow`.

### Centered Text Overlay Recipe (Hook, CTA, URL)
Point text in FilmCraft anchors at the left edge (`Choice(0)`), causing text placed at `[540, y]` to overflow the right boundary. Use this verified 3-step recipe for centered text:
1. Create text layer (using `size: 64` or wrapping in `box: [w, h]`):
   ```json
   {"id": "graphics.newText", "params": {"text": "HEADLINE HOOK", "font": "Bebas Neue", "size": 64, "position": [540, 600], "seconds": 3.0, "time": 0}}
   ```
2. Set text justification to center (`Choice(1)`):
   ```json
   {"id": "graphics.set", "params": {"clip": <clip_id>, "layer": 0, "props": {"align": "center", "position": [540, 600], "fill_color": "#FFFFFF", "stroke": true, "stroke_width": 6, "stroke_color": "#000000"}}}
   ```
3. Center horizontally on the frame:
   ```json
   {"id": "graphics.alignFrame.hcenter", "params": {"clip": <clip_id>, "layers": [0]}}
   ```
4. Read back the layer bounding box to verify it stays within `x 65-1015, y 270-1248`:
   ```powershell
   & "D:\7th SEM\FilmCraft\filmcraft-cli.exe" exec graphics.list clip=<clip_id>
   ```
   Inspect `layers[0].quad` (`[[x1,y1], [x2,y2], [x3,y3], [x4,y4]]`).

### Captions (Delegated to word-captions)
- Captions are **NOT** done in FilmCraft any more. FilmCraft caption tracks cannot highlight individual words.
- Export from FilmCraft without captions (`burnCaptions: false`) to `episodes/<n>/out/final_raw.mp4`.
- Captions are generated and burned in post via the `word-captions` skill (`scripts/make_ass.py` + `scripts/burn_captions.py` using ffmpeg libass with `fontsdir=assets/fonts`).

### Audio mixing (voice, music gain, SFX)
- Clip audio gain:
  ```json
  {"id": "clip.audioGain", "params": {"clips": [<clip_id>], "mode": "set|adjust|normalizeMax|normalizeAll", "db": -3.0}}
  ```
- Track & Master strip volume:
  ```json
  {"id": "mixer.setValue", "params": {"strip": "A1"|"A2"|"Mix", "lane": "volume", "value": -6.0}}
  ```

### Loudness
- Built into sequence mix:
  ```json
  {"id": "sequence.normalizeMixTrack", "params": {"db": -14.0}}
  ```
- Two-pass post-mix normalization (standard pipeline):
  `python .agents/skills/audio-mix/scripts/loudnorm2pass.py raw.mp4 final.mp4 --lufs -14 --tp -1.0`

### Export preset for reels (resolution, fps, bitrate)
- Built-in social reel preset:
  `"Social Vertical 1080×1920"` (1080x1920, 30 fps, H.264 VBR 12 Mbps target, AAC 320 kbps).
- Export via CLI command:
  ```powershell
  & "D:\7th SEM\FilmCraft\filmcraft-cli.exe" --project project.fcproj export episodes/001/out/final.mp4 --preset "Social Vertical 1080×1920"
  ```
- Export command via `file.exportMedia` (export without captions):
  ```json
  {"id": "file.exportMedia", "params": {"path": "episodes/001/out/final_raw.mp4", "preset": "Social Vertical 1080×1920", "burnCaptions": false, "wait": true}}
  ```

### Project/timeline file format
- `.fcproj` JSON format (UTF-8 JSON, `schema_version: 15`, `generator: "FilmCraft 0.12.0"`).
- Inspect project / sequence structure:
  ```powershell
  & "D:\7th SEM\FilmCraft\filmcraft-cli.exe" --project project.fcproj inspect sequence
  ```

## Limits / gaps
1. **Word-by-word caption highlight**: FilmCraft caption tracks apply uniform styling to full phrases; per-word highlight is NOT SUPPORTED natively in caption tracks. The pipeline either builds text layers or handles karaoke highlight rendering via ffmpeg.
2. **Arbitrary external TTF file loading in font parameter**: Font names (e.g. `"Bebas Neue"`) resolve from system-installed fonts and FilmCraft registered fonts. If an arbitrary unregistered TTF file path is supplied, FilmCraft defaults to its fallback font (`Inter`).

## Conventions
- Work in `episodes/<n>/`; export sequence without captions to `out/final_raw.mp4`, run `word-captions` (`burn_captions.py` -> `out/final_captioned.mp4`), then run `audio-mix` (`loudnorm2pass.py` -> `out/final.mp4`).
- One build script per episode (`tools/build_episode.*`) that turns `timeline.json` into FilmCraft calls, so a new episode is one command.
- Execute `render-qc` on `out/final.mp4` and review contact sheet and safe zone frames before delivery.
