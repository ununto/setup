#!/usr/bin/env python
"""Audio (+ optional script text) -> words.json with the EXACT script spelling and real voice timings.
Usage: align_words.py audio.mp3 --script episodes/001/script_vo.txt --out episodes/001/words.json [--model base.en] [--lang en]
Needs: pip install faster-whisper   (downloads a small model on first run; CPU is fine with tiny.en/base.en).
Why script mapping: speech recognition misspells tool names (ArtCraft -> "art craft"); we keep ASR timings but your spelling.
Output: [{"i":0,"w":"It's","start_ms":0,"end_ms":190}, ...]"""
import argparse, difflib, json, re, sys

def norm(s):
    return re.sub(r"[^a-z0-9]", "", s.lower())

def map_script_to_asr(script, asr):
    """script: list[str]; asr: list[{w,start,end}] (seconds). Returns list[(start,end)] per script word."""
    S = [norm(x) for x in script]; A = [norm(x["w"]) for x in asr]
    res = [None] * len(script)
    sm = difflib.SequenceMatcher(None, S, A, autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            for d in range(i2 - i1):
                res[i1 + d] = (asr[j1 + d]["start"], asr[j1 + d]["end"])
        elif tag == "replace":
            t0, t1 = asr[j1]["start"], asr[j2 - 1]["end"]
            wts = [max(1, len(S[k])) for k in range(i1, i2)]; tot = sum(wts); cur = t0
            for k, wt in zip(range(i1, i2), wts):
                nxt = cur + (t1 - t0) * wt / tot
                res[k] = (cur, nxt); cur = nxt
    # fill words the recogniser dropped by interpolating between known neighbours
    dropped = {k for k, r in enumerate(res) if r is None}
    k = 0
    while k < len(res):
        if res[k] is not None: k += 1; continue
        j = k
        while j < len(res) and res[j] is None: j += 1
        t0 = res[k - 1][1] if k > 0 else 0.0
        t1 = res[j][0] if j < len(res) else t0 + 0.35 * (j - k)
        wts = [max(1, len(S[m])) for m in range(k, j)]; tot = sum(wts); cur = t0
        for m, wt in zip(range(k, j), wts):
            nxt = cur + max(0.0, t1 - t0) * wt / tot
            res[m] = (cur, nxt); cur = nxt
        k = j
    # a dropped (reduced) word like "the" needs a readable slot: borrow time from its neighbours
    res = [list(r) for r in res]; MIN = 0.11
    for k in sorted(dropped):
        need = MIN - (res[k][1] - res[k][0])
        if need <= 0: continue
        if k > 0:
            take = min(need, max(0.0, (res[k - 1][1] - res[k - 1][0]) - 0.12))
            res[k - 1][1] -= take; res[k][0] -= take; need -= take
        if need > 0 and k + 1 < len(res):
            take = min(need, max(0.0, (res[k + 1][1] - res[k + 1][0]) - 0.12))
            res[k + 1][0] += take; res[k][1] += take
    # enforce monotonic, minimum 40 ms
    out, prev_end = [], 0.0
    for s, e in res:
        s = max(s, prev_end); e = max(e, s + 0.04); out.append((s, e)); prev_end = e
    ratio = sum(1 for t in sm.get_opcodes() if t[0] == "equal" for _ in range(t[2] - t[1])) / max(1, len(script))
    return out, ratio

def run_asr(audio, model, lang):
    import numpy as np, subprocess
    from faster_whisper import WhisperModel
    # Use ffmpeg to decode audio to 16kHz mono float32 (bypasses av.open metadata_errors bug in av>=19)
    cmd = ['ffmpeg', '-y', '-i', audio, '-f', 'f32le', '-ac', '1', '-ar', '16000', '-']
    raw = subprocess.check_output(cmd, stderr=subprocess.DEVNULL)
    audio_data = np.frombuffer(raw, dtype=np.float32)
    m = WhisperModel(model, device="cpu", compute_type="int8")
    segs, _ = m.transcribe(audio_data, word_timestamps=True, language=lang, beam_size=5)
    return [{"w": w.word.strip(), "start": float(w.start), "end": float(w.end)} for s in segs for w in s.words]

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("audio"); ap.add_argument("--script"); ap.add_argument("--out", required=True)
    ap.add_argument("--model", default="base.en"); ap.add_argument("--lang", default="en")
    a = ap.parse_args()
    asr = run_asr(a.audio, a.model, a.lang)
    if not asr: sys.exit("no speech recognised")
    if a.script:
        words = [t for t in open(a.script, encoding="utf-8").read().split() if norm(t)]
        times, ratio = map_script_to_asr(words, asr)
        if ratio < 0.7: print(f"WARNING: only {ratio:.0%} of script words matched the audio; check script vs recording", file=sys.stderr)
    else:
        words = [x["w"] for x in asr]; times = [(x["start"], x["end"]) for x in asr]; ratio = 1.0
    out = [{"i": i, "w": w, "start_ms": int(round(s * 1000)), "end_ms": int(round(e * 1000))}
           for i, (w, (s, e)) in enumerate(zip(words, times))]
    json.dump(out, open(a.out, "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    print(json.dumps({"words": len(out), "script_match": round(ratio, 2), "first_ms": out[0]["start_ms"], "last_ms": out[-1]["end_ms"]}))
