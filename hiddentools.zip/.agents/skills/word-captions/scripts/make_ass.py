#!/usr/bin/env python
"""words.json -> ASS captions, ONE WORD AT A TIME, pop-in animation, restrained highlight.
Usage: make_ass.py words.json --out episodes/001/out/captions.ass [--style assets/brand/word_caption_style.json]
words.json items may carry "hl": true/false to force/forbid highlight; otherwise auto rules apply."""
import argparse, json, re, sys

DEFAULT = {
  "font_family": "Bebas Neue", "font_size_px": 170, "uppercase": True, "strip_punct": True,
  "text_color": "#FFFFFF", "highlight_color": "#FFD60A", "outline_color": "#000000", "outline_px": 12,
  "anchor_y_px": 1130, "safe_x_min": 65, "safe_x_max": 1015, "char_width_em": 0.46,
  "pop": {"from_pct": 82, "peak_pct": 108, "peak_ms": 70, "settle_ms": 70},
  "pause_clear_ms": 350, "linger_ms": 150, "tail_ms": 300, "min_word_ms": 90,
  "highlight_min_gap_words": 3,
  "emphasis_words": ["free", "zero", "hidden", "secret", "instantly", "nobody", "never", "forever", "stop"]
}

def hex_bgr(h):
    h = h.lstrip("#"); return f"&H{h[4:6]}{h[2:4]}{h[0:2]}&".upper()

def ts(ms):
    cs = int(round(ms / 10)); h, cs = divmod(cs, 360000); m, cs = divmod(cs, 6000); s, c = divmod(cs, 100)
    return f"{h}:{m:02d}:{s:02d}.{c:02d}"

def clean(w, st):
    if st.get("strip_punct"):
        t = re.sub(r"^[\s.,;:!?\"“”()\[\]]+|[\s.,;:!?\"“”()\[\]]+$", "", w)
        t = re.sub(r"[\"“”()\[\]]", "", t)
    else:
        t = w.strip()
    return t.upper() if st["uppercase"] else t

def build(words, st):
    n, lines, last_hl, shrinks, hls = len(words), [], -99, 0, 0
    emph = {re.sub(r"[^a-z0-9]", "", x.lower()) for x in st["emphasis_words"]}
    X = (st["safe_x_min"] + st["safe_x_max"]) // 2; Y = st["anchor_y_px"]
    p = st["pop"]
    for k, w in enumerate(words):
        txt = clean(w["w"], st)
        if not txt: continue
        start = w["start_ms"]; nxt = words[k + 1]["start_ms"] if k + 1 < n else None
        if nxt is None: end = w["end_ms"] + st["tail_ms"]
        else:
            pause = nxt - w["end_ms"]
            end = nxt if pause <= st["pause_clear_ms"] else w["end_ms"] + st["linger_ms"]
        end = max(end, start + st["min_word_ms"])
        if nxt is not None: end = min(end, nxt) if nxt - start >= 40 else end
        key = re.sub(r"[^a-z0-9]", "", w["w"].lower())
        auto = bool(re.search(r"\d", key)) or key in emph or ("." in w["w"].strip(".,") and re.search(r"[a-z]\.[a-z]", w["w"].lower()))
        hl = w.get("hl")
        if hl is None:
            hl = bool(auto) and (k - last_hl) > st["highlight_min_gap_words"]
        if hl: last_hl = k; hls += 1
        fs = st["font_size_px"]; maxw = st["safe_x_max"] - st["safe_x_min"]
        if len(txt) * st["char_width_em"] * fs > maxw:
            fs = int(maxw / (len(txt) * st["char_width_em"])); shrinks += 1
        col = hex_bgr(st["highlight_color"] if hl else st["text_color"])
        tags = (f"{{\\an5\\pos({X},{Y})\\fs{fs}\\bord{st['outline_px']}\\shad0\\1c{col}"
                f"\\fscx{p['from_pct']}\\fscy{p['from_pct']}"
                f"\\t(0,{p['peak_ms']},\\fscx{p['peak_pct']}\\fscy{p['peak_pct']})"
                f"\\t({p['peak_ms']},{p['peak_ms'] + p['settle_ms']},\\fscx100\\fscy100)}}")
        lines.append(f"Dialogue: 0,{ts(start)},{ts(end)},Word,,0,0,0,,{tags}{txt}")
    return lines, {"events": len(lines), "highlighted": hls, "shrunk_long_words": shrinks}

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("words"); ap.add_argument("--out", required=True); ap.add_argument("--style")
    ap.add_argument("--shift-ms", type=int, default=0, help="add to every time (e.g. where the voiceover starts on the timeline, or +/-80 to nudge sync)")
    a = ap.parse_args()
    st = json.loads(json.dumps(DEFAULT))
    if a.style:
        user = json.load(open(a.style, encoding="utf-8"))
        for k, v in user.items():
            if isinstance(v, dict) and k in st and isinstance(st[k], dict): st[k].update(v)
            elif not k.startswith("_"): st[k] = v
    words = json.load(open(a.words, encoding="utf-8"))
    for w in words: w["start_ms"] += a.shift_ms; w["end_ms"] += a.shift_ms
    lines, info = build(words, st)
    head = ("[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\nWrapStyle: 2\nScaledBorderAndShadow: yes\n\n"
            "[V4+ Styles]\nFormat: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,"
            "Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding\n"
            f"Style: Word,{st['font_family']},{st['font_size_px']},{hex_bgr(st['text_color']).replace('&H','&H00').rstrip('&')},"
            f"&H00FFFFFF,{hex_bgr(st['outline_color']).replace('&H','&H00').rstrip('&')},&H64000000,0,0,0,0,100,100,1,0,1,"
            f"{st['outline_px']},0,5,40,40,40,1\n\n[Events]\nFormat: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text\n")
    open(a.out, "w", encoding="utf-8-sig").write(head + "\n".join(lines) + "\n")
    print(json.dumps({"out": a.out, **info}))
