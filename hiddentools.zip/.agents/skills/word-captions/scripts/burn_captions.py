#!/usr/bin/env python
"""Burn ASS captions into a video (re-encodes video at CRF 18, copies audio).
Run from the PROJECT ROOT (same drive as the files) so paths are relative and Windows-safe:
  python .agents/skills/word-captions/scripts/burn_captions.py episodes/001/out/final_raw.mp4 episodes/001/out/captions.ass --out episodes/001/out/final_captioned.mp4
Fonts are loaded from --fonts (default assets/fonts) so the exact font file is used."""
import argparse, os, subprocess, sys

ap = argparse.ArgumentParser()
ap.add_argument("video"); ap.add_argument("ass"); ap.add_argument("--out", required=True)
ap.add_argument("--fonts", default="assets/fonts")
a = ap.parse_args()
try:
    rel = lambda p: os.path.relpath(p).replace("\\", "/")
    ass, fonts = rel(a.ass), rel(a.fonts)
except ValueError:
    sys.exit("Run from the project root on the same drive as the files (relative paths avoid Windows colon escaping).")
vf = f"ass=filename='{ass}':fontsdir='{fonts}'"
cmd = ["ffmpeg", "-hide_banner", "-y", "-i", a.video, "-vf", vf, "-c:v", "libx264", "-crf", "18", "-preset", "medium",
       "-pix_fmt", "yuv420p", "-c:a", "copy", "-movflags", "+faststart", a.out]
r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
if r.returncode != 0:
    sys.exit("burn failed (needs an ffmpeg build with libass, e.g. the gyan.dev full build):\n" + r.stderr[-800:])
print("ok:", a.out)
