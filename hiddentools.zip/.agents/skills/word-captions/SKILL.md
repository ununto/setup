---
name: word-captions
description: One-word-at-a-time viral captions synced to the voiceover - aligns the recorded voice to the exact script words, generates animated ASS captions (Bebas Neue, pop-in, restrained highlight), burns them in with ffmpeg, and verifies sync on frames. Use whenever adding captions/subtitles to a reel, when captions look early/late, or when the user supplies a voiceover file.
---

# Word captions (1 word at a time, synced to the voice)

FilmCraft caption tracks style whole phrases and cannot highlight single words, so captions are burned with ffmpeg/libass AFTER the FilmCraft export. Do not use `captions.*` or `burnCaptions` in FilmCraft for this reel.

## Inputs
- The voiceover audio the user made (ElevenLabs etc.): `episodes/<n>/vo.wav` or `.mp3`.
- `episodes/<n>/script_vo.txt`: the EXACT spoken text only (no stage directions). Keep tool names spelled as they should appear (ReactBits, getartcraft.com).

## Pipeline position
FilmCraft export WITHOUT captions -> `out/final_raw.mp4` -> burn captions -> `out/final_captioned.mp4` -> audio-mix (loudnorm2pass) -> `out/final.mp4` -> render-qc. (Burn first: it re-encodes video; loudnorm then copies the video untouched.)

## Steps (run from the project root; use `python`, forward slashes)
1. Ask the user before installing: `pip install faster-whisper` (downloads a small speech model on first run; `base.en` runs on a weak CPU, `tiny.en` is faster but less accurate).
2. Align: `python .agents/skills/word-captions/scripts/align_words.py episodes/<n>/vo.wav --script episodes/<n>/script_vo.txt --out episodes/<n>/words.json`
   - Reports `script_match`. Below 0.7 means the recording differs from the script: stop and ask the user.
   - Uses recognition timings with your spelling; dropped or merged words are interpolated.
3. Optionally force emphasis: edit `words.json` and add `"hl": true` on 1-2 power words (tool name, "free", a number). Auto rules also highlight digits, URLs and words in `emphasis_words`, never closer than 3 words apart.
4. Generate: `python .agents/skills/word-captions/scripts/make_ass.py episodes/<n>/words.json --style assets/brand/word_caption_style.json --out episodes/<n>/out/captions.ass --shift-ms <ms>`
   - `--shift-ms` = where the voiceover starts on the FilmCraft timeline (0 if it starts at 0).
5. Burn: `python .agents/skills/word-captions/scripts/burn_captions.py episodes/<n>/out/final_raw.mp4 episodes/<n>/out/captions.ass --out episodes/<n>/out/final_captioned.mp4`
6. VERIFY SYNC (required): extract frames at the midpoint of 6 words spread across the video (first word, a highlighted word, a long word, a fast word, a word after a pause, the last word) with `ffmpeg -ss <t> -i ... -frames:v 1`. LOOK at them: the word on screen must be the word being spoken at that time, and text must be inside the safe box (y 270-1248). If all captions are consistently early or late, re-run step 4 with `--shift-ms` +/-60 to 120.

## Style rules (keep restraint)
- One word at a time, centered, uppercase, heavy condensed font (Bebas Neue, ~170 px), thick black outline (~12 px), white text, ONE accent color (yellow #FFD60A) on power words only.
- Pop-in: scale 82% -> 108% -> 100% in about 140 ms. No rotation, color cycling or emoji spam: too busy hurts readability.
- Hold each word until the next one starts; clear during pauses over 350 ms.
- Position: just below the demo panel, inside the safe box (default y 1130). The hook headline sits above the panel.
- Long words shrink automatically to stay inside x 65-1015.
See `references/styles.md` for sources and caveats.
