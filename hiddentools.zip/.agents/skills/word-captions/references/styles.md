# Caption style research notes (Nov 2026)

Sources agree (mostly vendor blogs - treat retention numbers as unverified marketing):
- Word-by-word highlighted/animated captions are the dominant 2026 Reels style. Hormozi-style = bold uppercase, thick outline, white text with one yellow (or green) power word, quick pop/scale-in.
- Fonts named: Montserrat Black, Anton, Bebas Neue. Highlight colors named: #FFD93D yellow, #39FF14 green. Size guidance varies (92 px on 1080x1920 for Montserrat; 80-120 px). Condensed Bebas needs a bigger size (we use ~170 px) to fill the same visual width.
- Restraint: highlight one word per line or a few per clip; when every third word is colored, nothing stands out. Animated captions hurt only when too busy.
- Single-word style suits short clips (5-30 s) and fast delivery; 2-3 word chunks suit longer videos.
- Claimed lifts (+15-40% watch time, +25-38% retention) come from vendor case studies; there is no independent measurement. Test on your own account: same hook with and without highlight.
- Placement: keep inside the Reels safe box (see captions-and-safe-zone).
