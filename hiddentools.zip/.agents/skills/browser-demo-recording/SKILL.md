---
name: browser-demo-recording
description: How to record clean browser/website demo footage for reels with Playwright - discover, rehearse, then record; visible smooth cursor, native resolution, per-scene clips, timing against the voiceover. Use whenever capturing a website or web tool on screen, recording a walkthrough, or when existing screen footage looks soft, jumpy or hard to read.
---

# Browser demo recording

Three phases, never skip to recording: **Discover -> Rehearse -> Record**.

1. **Discover**: open the site, list the 3-4 actions that show the value (input -> effect -> result). Note stable selectors. Pick the single "wow" moment.
2. **Rehearse**: run every step with recording OFF. Silent selector failures are the main reason demo recordings break. Fix selectors before recording.
3. **Record**: one clip per scene, at real speed, with ~0.5 s of padding before and after each clip (the editor trims).

## Capture settings
- Record at native resolution; crisp text beats a re-scaled capture. Use a 2x device scale factor where possible, then crop/zoom to the focal region in the edit.
- Playwright outputs WebM. Convert to H.264 MP4 (yuv420p, 30 fps) before editing: `ffmpeg -i in.webm -c:v libx264 -pix_fmt yuv420p -r 30 -an out.mp4`.
- Newer Playwright versions have a screencast API with action annotations and chapters; check the installed version's docs before using.

## Cursor and motion
- Playwright shows no cursor by default: inject an overlay that follows mouse events (arrow + click ripple).
- Never teleport the cursor: move in steps/easing. Use smooth scrolling (`behavior: 'smooth'`), not jumps.
- Pause 300-600 ms on the result so it can be read; that hold is the "proof" beat.

## Sync with the voice
- Scene start times come from `timeline.json` (anchored to words). Each scene's actions must finish inside its slot; if a clip is 10-20% off, retime it in the edit, if more, re-record with shorter waits.
- Hide cookie banners, personal data, tabs, bookmarks and notifications. Use a clean browser profile.

## Do not
- Re-film a monitor, use perspective-warped mockups, or leave tiny unreadable UI text: zoom to the region instead.
- Record anything behind a login or personal account on camera.
