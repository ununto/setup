---
name: hiddentool-brand
description: Channel identity for @hiddentool.si - persona, tone, visual look, series naming, what to keep consistent vs vary, AI-content honesty. Use for every script, visual choice, caption style or episode naming decision on this channel.
---

# @hiddentool.si brand

- **Persona**: anonymous armored traveler / sci-fi warrior (weathered steel armor, metal gauntlets, dark green hooded cloak). Tone: unbothered tech insider - gritty, authoritative, slightly dystopian, zero fluff, no corporate marketing speak. Tools feel like internet cheat codes.
- **The Secret / Gatekeeper Strategy**: NEVER reveal the tool name or website URL in the video or voiceover. Treat every tool as an unindexed secret. Viewers must comment a keyword to get the private link sent via DM.
- **Hook Visuals**: Every episode starts (Frame 0) with a hyper-detailed, cinematic 9:16 vertical AI visual (generated from tailored prompts) or dynamic proof.
- **Audience**: US/UK creators, developers, students, professionals who want pro tools without monthly subscriptions.
- **Look**: unpolished, high-end consumer-camera dynamic range, visible fine grain, subtle handheld sway, no UI clutter or watermarks. Browser footage stays crisp and readable (the "proof").
- **Series**: "Part N" numbering. Check the previous episode number before naming (test files used "EP. 50" for ArtCraft while notes list ArtCraft as 51-52).
- **Keep consistent**: character, color grade, caption style/position, voice, beat structure, CTA wording, end card.
- **Vary**: hook pattern, location, analogy, first frame, tool category.
- **AI honesty**: scenes may be AI-generated; label per platform rules, vary scenes so the channel does not read as templated, and keep real screen recordings of real tools as the core. Instagram has said it will reward original, authentic content; do not publish near-identical templated clips.
- **Fonts/colors**: set in `assets/brand/caption_style.json` (defaults only until you choose).
