---
name: voiceover
description: Generate the voiceover with local VoiceStudio over MCP and produce word-level timings (words.json) that drive scene timing and captions. Use whenever a script needs audio, a voice needs regenerating, or word timestamps are needed.
---

# Voiceover (VoiceStudio, local, open source)

1. VoiceStudio app must be running. MCP endpoint: `http://localhost:3900/mcp` (keep it localhost-only; the transport is unauthenticated).
2. Read the VoiceStudio MCP docs (docs/mcp.md in its repo) once. Tools include `generate_speech`, `clone_voice`, `transcribe`, `list_voices`, `check_health`.
3. `check_health`, then `list_voices`. Use the voice named in `assets/brand/` notes (or ask the user). Clone only voices the user has rights to.
4. `generate_speech` with `episodes/<n>/script.md` text -> decode the returned WAV to `episodes/<n>/vo.wav`.
5. Word timings: if `transcribe` does not return word-level times, run a Whisper-style aligner locally (faster-whisper with word timestamps, or `npx hyperframes transcribe`) on `vo.wav` -> `words.json` as `[{"i":0,"w":"It's","start_ms":0,"end_ms":190}]`.
6. Check length with `ffprobe`: target <= 13.5 s of speech. If longer, shorten the script, do not speed up the voice past natural.
7. Optional "metallic" timbre: light EQ/distortion via ffmpeg on a COPY of the file; keep the clean original.
8. Before commercial use confirm the licence of the specific voice model (app licence and model-weight terms are separate).
