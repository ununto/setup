---
name: hook-and-cta
description: Hook, script and CTA system for @hiddentool.si tool-discovery reels - analogy-first hook formula, 10 hook patterns, 36-word script budget, 14-second beat template, CTA alternation. Use whenever writing or revising a reel script, hook line, on-screen headline or call to action.
---

# Hook, script, CTA

## Platform reality (research, Oct 2026)
Instagram says watch time, likes per reach and sends per reach matter most for Reels; sends are the strongest for reaching non-followers. Design for: finish-watching (short + loop), and a reason to send it to someone. Hook-percentage stats online are mostly vendor claims; treat as directional.

## Hook Visual / AI Image Prompt Generation (Mandatory for Every Episode)
Every time a script is proposed, you MUST include 1–2 high-converting **AI Image Prompts** (optimized for ChatGPT DALL-E 3 / Midjourney) to generate the Frame 0 visual hook:
- **Aspect Ratio**: Vertical 9:16 (`--ar 9:16` or explicitly "vertical 9:16 cinematic image").
- **Visual Style**: Octane Render, Unreal Engine 5 quality, hyper-realistic, tilt-shift miniature, glowing isometric holograms, dramatic studio or cyberpunk lighting.
- **Goal**: Instantly stop the user from scrolling on Frame 0 (e.g. glowing 3D city in crystal glass cube, holographic futuristic interface emerging from laptop, etc.).

## Curiosity Loop & Gatekeeping (Hide Website Name)
- **Zero Name Leaks**: Never mention the tool's actual name or domain (`.com`, `.ai`) in the voiceover script or captions.
- **Phrasing**: Use mystery-driven phrases like *"This hidden website"*, *"This secret AI tool"*, *"Nobody told you this free platform exists"*.
- **The Conversion Engine**: Forcing curiosity makes viewers comment to get the URL. The CTA must always be comment-driven (*"Comment LINK"*, *"Comment 3D"*, *"Comment TOOL"*).
- The actual link is delivered exclusively via automated DMs (ManyChat).

## Script budget
Max 36 words total (~2.5 words/s). Hook <= 8 words (<= 2.5 s). One benefit per sentence.

## Beat template (14 s)
0.0-2.5 hook (text + proof at frame 0) -> 2.5-3.5 name + URL -> 3.5-6.5 demo 1 -> 6.5-9.5 demo 2 (the wow) -> 9.5-11.5 proof held >= 1 s -> 11.5-14.0 CTA + loop line.

## Hook formula
[analogy] + [price/effort twist] + [tool name]. Templates:
1. "It's [paid tool] without [the cost / the install]."
2. "It's [tool A] meets [tool B], in one tab."
3. "It's a free [role] that lives in your browser."
4. "Pro-grade [capability], minus [the gatekeeper]."
5. "The cheat code for [annoying task]. Nobody's gatekeeping it."
Example: "It's Adobe, if Adobe forgot to charge you. ... ArtCraft. Open source. Zero ads."

## 10 patterns (rotate; never repeat the same one twice in a row)
Analogy | Price contrast ("Companies bill monthly for this. This bills nothing.") | Stop-scroll ("Stop. Close your paid editor.") | Curiosity gap ("Nobody told you this tab exists.") | Proof-first (result at 0.0 s, "Ten seconds. Zero dollars.") | Contrarian ("You don't need another subscription.") | Mistake ("You're still paying for this?") | Number ("One website replaces five paid tools.") | Persona ("They hoped you'd never find this.") | Challenge ("Name one thing this can't do.")

## CTA (one per reel, alternate to learn what works)
- Odd episodes: "Comment LINK" (keyword -> link by DM). Use only official/Meta-approved automation.
- Even episodes: "Send this to someone still paying for [X]" (targets sends).
- URL on screen when spoken. End line should loop back to the hook.
- Compare sends-per-reach and saves-per-reach in Insights after 48 h before choosing a winner.
