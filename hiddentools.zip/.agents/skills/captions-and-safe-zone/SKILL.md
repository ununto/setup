---
name: captions-and-safe-zone
description: Caption and on-screen text rules for 9:16 reels - safe-zone coordinates, caption size, word-by-word timing from words.json, highlight and contrast rules, font handling. Use whenever adding captions, subtitles, hook text, CTA text, URL text or any overlay, and whenever checking text placement.
---

# Captions and safe zone (1080x1920)

## Safe box
- Reels UI covers roughly the top 14%, bottom 35% (40% at bottom-right), and 6% on each side.
- All text and any critical UI must sit inside: x 65-1015, y 270-1248. Captions default to anchor y ~1040.
- Sources disagree slightly on exact margins (some allow y up to ~1420). Use the stricter box above.

## Caption rules
- Source of truth: `episodes/<n>/words.json`. Never retype caption text.
- Word-by-word or 2-4 word chunks, broken by meaning, max 2 lines, about 26 characters per line (heuristic).
- Size 48-64 px minimum for body captions; heavy sans, stroke 4-6 px or a dark pill for contrast.
- One highlighted word per line at most (use `highlight.color` in `assets/brand/caption_style.json`).
- Hook headline (large, centered, frame 0) is separate from captions. CTA text is separate too.
- URL appears on screen exactly when the voice says it, large enough to read on a phone (>= 56 px).

## Fonts
- Load fonts only from `assets/fonts/` (open-licensed, e.g. OFL: Bebas Neue, Oswald, Inter, Montserrat). Set the file in `assets/brand/caption_style.json`.
- How FilmCraft loads a font file is documented in `filmcraft-edit/SKILL.md`. If undocumented, run its `--help` and record the answer there.
- If rendering with ffmpeg/libass instead: `subtitles=captions.ass:fontsdir=assets/fonts`.

## Verify
`render-qc` produces safe-zone overlay frames (red bands = unsafe). Look at them. Text inside a red band is a failure.
