# timeline.json schema (renderer-agnostic)

```json
{
  "meta": {"id": "hidden-tools-053", "fps": 30, "width": 1080, "height": 1920, "duration_ms": 13800},
  "audio": {"voice_file": "vo.wav", "music": {"file": "assets/music/bed.mp3", "gain_db": -22}, "sfx": [{"t_ms": 2600, "file": "assets/sfx/hit.wav"}]},
  "words": [{"i": 0, "w": "It's", "start_ms": 0, "end_ms": 190}],
  "scenes": [
    {
      "id": "s1_hook", "beat": "hook",
      "anchor": {"from_word": 0, "to_word": 7},
      "start_ms": 0, "end_ms": 2600,
      "visual": {"type": "browser|ai_clip|still", "file": "episodes/053/raw/clip1.mp4"},
      "camera": {"move": "push_in", "zoom": 1.08},
      "headline": "ONE WEBSITE. 13 FREE APPS?",
      "caption": {"mode": "word_by_word", "style": "assets/brand/caption_style.json"}
    }
  ]
}
```

Rules
- `words` and every `start_ms`/`end_ms` are GENERATED from the voice track, never typed by hand.
- scene[i].end_ms == scene[i+1].start_ms; the last scene ends at the audio length.
- Browser steps (if any) use `at_ms` relative to scene start.
- Beats: hook (0-2.5 s) -> name (URL on screen) -> demo 1 -> demo 2 -> proof -> cta+loop.
