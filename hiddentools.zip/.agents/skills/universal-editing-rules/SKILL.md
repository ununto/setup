---
name: universal-editing-rules
description: Universal short-form editing rules that apply to EVERY reel - where to cut, cut rhythm, pacing, zooms, text hierarchy, frame positioning, and the order of edit operations. Use this skill whenever planning, cutting, timing, reframing or reviewing any 9:16 video, even if the user only says "edit this" or "make it tighter".
---

# Universal editing rules (apply to every video)

These are craft rules, not laws. Where sources disagree, the rule says so. Break a rule only for a reason you can state.

## 1. Where to cut
- Cut at the end of a complete thought, and on movement (click, scroll, zoom start), not mid-motion.
- Never cut inside a spoken word. Snap cuts to word boundaries from `words.json`.
- Keep a small breath/pad at cut edges; add ~30 ms audio fades at cuts to avoid clicks.
- Remove repeated meaning, dead air and false starts. Do not remove every pause - it should still sound human.

## 2. Rhythm (guideline, not a stopwatch)
- There is NO universal "cut every 2 seconds" law. Match cut rate to content: a demo showing a result can hold 3-4 s if something is developing on screen.
- Default for this channel: a visual change (cut, zoom, text state, new UI region) roughly every 1.5-3 s. If a shot holds longer than 4 s, something must be changing inside it.
- Every cut, punch-in, caption emphasis or SFX needs a job (new info, emphasis, or reset of attention). If it has no job, delete it. Never SFX every cut.
- Pattern interrupts (zoom, cut, graphic) go where attention would otherwise drop: after the hook, and before the CTA.

## 3. Opening and ending
- 0.0-2.5 s: hook text + proof visible at frame 0. Never a logo slate, tagline, "hey guys", or ambient b-roll.
- Last second matters: end on the result or a loop point, not on silence. Trim any silent tail over 0.3 s.
- Total length 12-14 s. The ending line should flow back into the opening line so the loop feels natural.

## 4. Position and framing (1080x1920)
- Focal content (cursor, result, face, UI being demonstrated) lives in the middle 60% of the frame.
- Safe box for ALL text and critical UI: x 65-1015, y 270-1248. Reels UI covers the top ~14%, bottom ~35%, sides ~6%.
- Browser footage: full-bleed, native resolution, cropped/zoomed to the region that matters. Never re-film a monitor, never use warped perspective mockups.
- Hide Website Name & URL: ALWAYS crop or blur out the browser URL address bar and website header logo. Do not leak the tool's name or domain visually, so viewers must comment for the DM link.
- Zooms ease in/out (no linear, no jitter). Max one punch-in per beat. Follow the cursor smoothly.

## 5. Text hierarchy
- Headline/hook text is separate from captions. Captions transcribe speech; headlines state the promise.
- One highlighted word per caption line at most. Break lines by meaning.
- Readable on every frame: stroke or pill behind text; never over busy UI without contrast.

## 6. Order of operations (never reorder)
cut -> pace/retime -> zooms/reframe -> hook text -> captions (last visual step) -> music/SFX -> loudness (last audio step) -> QC.

## 7. Plan before rendering
Write `timeline.json` first (schema: `references/timeline-schema.md`). Scenes are anchored to spoken words so picture follows voice. Show the plan to the user before the first full render when a new style or tool is involved.
