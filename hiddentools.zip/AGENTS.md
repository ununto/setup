# @hiddentool.si — agent operating rules

You produce 12–14 s vertical reels (1080x1920, 30 fps, H.264) about hidden tools and websites.
Inputs: raw clips in `episodes/<n>/raw/`, a script, a voiceover. Output: `episodes/<n>/out/final.mp4`.
All editing goes through the FilmCraft CLI (see `filmcraft-edit`). Audio is the clock.

## Pipeline (never reorder)
1. `hook-and-cta`  -> script (max 36 words), hook, CTA. Follow `hiddentool-brand`.
2. `voiceover`     -> `vo.wav` (VoiceStudio) -> `words.json` (word timings).
3. `browser-demo-recording` -> native-resolution clips (rehearse before recording).
4. `universal-editing-rules` -> plan -> `timeline.json` (scenes anchored to spoken words).
5. `filmcraft-edit` -> assemble. Captions are the LAST visual step (`captions-and-safe-zone`).
6. `audio-mix`     -> final loudness pass.
7. `render-qc`     -> run qc.py, LOOK at the contact sheet and safe-zone frames, fix, re-run.
Only say "done" after render-qc has no FAIL and you have viewed the images.

## Hard rules
- Frame 0 shows hook text AND proof (the tool/result). Never open on a logo, tagline or slate.
- Never hand-type timestamps. Scene times come from words.json; captions come from words.json.
- All text stays inside the safe box x 65-1015, y 270-1248 (1080x1920 frame).
- Final audio: about -14 LUFS integrated, true peak -1 dBTP or lower. No silence tail over 0.3 s.
- Fonts only from `assets/fonts/`. Music/SFX only from `assets/` (licensed).
- Use only FilmCraft commands documented in `filmcraft-edit/SKILL.md`. If unsure, run `--help`.

## Safety
- Ask before installing any package, running an unknown script, or touching files outside this folder.
- Never read or modify files outside this project (no ~/.ssh, no other agents' memory files).
- Third-party skills: read every file first, copy (vendor) into `.agents/skills/`, never auto-update.

## Windows notes
- This machine is Windows: run Python as `python` (or `py`), never `python3`. If a command is not found, try the other name once.
- ffmpeg/ffprobe must be on PATH (winget install Gyan.FFmpeg). Use forward slashes in paths.
- Use `where.exe <tool>` (not `where`) in PowerShell to locate a tool.
