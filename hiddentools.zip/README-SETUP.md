# hidden-tools setup pack

## Install (5 minutes)
1. Unzip so the folder `hidden-tools/` is your project. Open THAT folder in Antigravity (File > Open Folder).
2. Antigravity reads `AGENTS.md` and `.agents/skills/` automatically. Restart the agent session after adding skills.
   (If your build looks for `.agent/skills` instead, rename the folder - both names have been used.)
3. Claude Code too? From the project root: `mkdir -p .claude && ln -s ../.agents/skills .claude/skills` and make `CLAUDE.md` contain only `@AGENTS.md`.
4. Drop your fonts in `assets/fonts/`, then edit `assets/brand/caption_style.json`.
5. Paste these prompts, in order:
   a) FilmCraft: "Follow the FIRST-RUN PROTOCOL in .agents/skills/filmcraft-edit/SKILL.md."
   b) VoiceStudio: "Connect to the VoiceStudio MCP at http://localhost:3900/mcp and test check_health/list_voices per .agents/skills/voiceover/SKILL.md."
   c) First episode: "Make episode 001 from episodes/001/raw using the pipeline in AGENTS.md. Show me timeline.json before the first render."

## Skills in this pack
Universal (every video): universal-editing-rules, captions-and-safe-zone, audio-mix, render-qc, browser-demo-recording, reference-study
Tool-specific: filmcraft-edit (self-documenting), voiceover (VoiceStudio)
Channel-specific: hook-and-cta, hiddentool-brand

Tested: render-qc/scripts/qc.py and audio-mix/scripts/loudnorm2pass.py were run on real reels (found -23.5 LUFS, fixed to -14.2 LUFS / -1.4 dBTP).
NOT tested: filmcraft-edit (needs your `filmcraft --help`), voiceover (needs VoiceStudio running), Antigravity skill loading.

## Optional third-party skills (read every file, copy into .agents/skills/, pin the commit)
| Repo | Licence | Use it for | Caution |
|---|---|---|---|
| zaddy99999/video-editing-skills | MIT | screen-recording footage: auto-cut, hook plate, word-highlight captions, loudnorm, render-qc, brand packs | brand new, 0 stars; skip `youtube-publish`; ffmpeg-based, not FilmCraft |
| kajisho5/ffmpeg-skill | MIT | 42 local ffmpeg tools, loudness, platform exports, CI-tested | `npx ffmpeg-skill` installs globally to ~/.claude/skills; copy instead |
| heygen-com/hyperframes (skills) | Apache-2.0 | captions, TTS (Kokoro), transcribe (Whisper), website-to-video, GSAP | separate render engine; use only if FilmCraft lacks a feature |
| nopefallacy/vertical-video-editing-skills | MIT (per another repo's credits) | editing standard, style packs, verify gate | HyperFrames-based |
| Melvynx/video-agent-skills, WhiteTowerAI/cut-as-code | not verified | /steal style extraction; karaoke captions | check licence first |
Avoid: appariciojunior/video-editor-skills (CC BY-NC, no commercial use), whole-catalog installs, anything with curl|bash.

## Skill security rules
Public registries have had real malicious skills (Snyk Feb 2026: 76 confirmed malicious of 3,984 audited; Koi: 341 of 2,857 on ClawHub). Before using any skill: read SKILL.md and every script; grep for curl, wget, base64, eval, `~/`, `.ssh`, `.env`, MEMORY/SOUL files; vendor a copy; never auto-update; keep terminal approvals on for the first runs.
